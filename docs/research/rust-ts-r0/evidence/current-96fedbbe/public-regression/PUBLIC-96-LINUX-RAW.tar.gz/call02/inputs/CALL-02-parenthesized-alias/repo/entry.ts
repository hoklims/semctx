export function original(): number { return 7; }
const alias = original;
export function invoke(): number { return (alias)(); }
