const display = { toString() { return "23"; } };
export function caption() { return String(display); }
