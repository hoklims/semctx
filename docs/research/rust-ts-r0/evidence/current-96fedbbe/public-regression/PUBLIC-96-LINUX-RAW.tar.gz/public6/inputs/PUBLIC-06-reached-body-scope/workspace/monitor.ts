export function refresh(destination: string) { return import(destination); }
