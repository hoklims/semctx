export type PublicStamp = { revision: number };
