const repeat = globalThis.setInterval;
export function begin() { return repeat("2+2", 5); }
