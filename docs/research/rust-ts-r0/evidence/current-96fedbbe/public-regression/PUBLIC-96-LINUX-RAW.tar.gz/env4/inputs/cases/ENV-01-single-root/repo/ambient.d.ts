declare const ambientCount: number;
