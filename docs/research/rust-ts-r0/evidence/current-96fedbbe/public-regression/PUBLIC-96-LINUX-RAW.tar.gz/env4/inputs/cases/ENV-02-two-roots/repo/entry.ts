import { count } from "./helper.js";
export function report(): number { return count(); }
