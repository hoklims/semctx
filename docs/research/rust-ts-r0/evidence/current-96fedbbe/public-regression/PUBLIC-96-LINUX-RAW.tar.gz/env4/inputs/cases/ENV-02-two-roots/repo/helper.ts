export function count(): number { return 2; }
