export class Counter {
  increment(value: number) { return value + 1; }
}
export function invoke() { return new Counter().increment(2); }
