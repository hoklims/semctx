"""DEV schema/path/layout fixtures only. No actual Windows outcome is claimed."""
import copy,hashlib,json,sys,unittest
from pathlib import Path

HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE/'package'))
import windows_transport as wt
import remaining_carriers as v
import qualified_carriers as q

HEAD='7baa717b63269eb2425ad8de7cc0e919d575128c';RUNNER='a'*64

class WindowsTransportTests(unittest.TestCase):
    def snapshot(self):return {'source_head':HEAD,'status':'','files':{'tools/rust-ts-r0/qualification/run_windows_milestone.py':RUNNER,'source.rs':'b'*64}}
    def build(self):
        before=self.snapshot();before['head']=before.pop('source_head')
        return {'source_head':HEAD,'source_before':before,'source_after':copy.deepcopy(before),'caller':{'sha256':RUNNER}}
    def test_source_alias_view_preserves_original_keys_hashes_and_head(self):
        before=self.snapshot();after=copy.deepcopy(before);build=self.build();original=copy.deepcopy((before,after,build));wt.source_pair(before,after,build,HEAD,RUNNER)
        self.assertEqual((before,after,build),original);self.assertNotIn('head',before)
        for name,change in [('foreign-head',lambda b,a,g:b.update(source_head='0'*40)),('dual-head',lambda b,a,g:b.update(head=HEAD)),('foreign-files',lambda b,a,g:g['source_before']['files'].update({'source.rs':'c'*64})),('foreign-caller',lambda b,a,g:g['caller'].update(sha256='0'*64)),('build-dual-head',lambda b,a,g:g.update(head=HEAD))]:
            b,a,g=copy.deepcopy(original);change(b,a,g)
            with self.subTest(name=name),self.assertRaises(ValueError):wt.source_pair(b,a,g,HEAD,RUNNER)
    def test_collector_aliases_are_exclusive_strict_and_not_native_outcome_rewrites(self):
        for receipt in ({'exit_code':0,'timed_out':False,'argv':['cargo']},{'exitCode':0,'timedOut':False,'argv':['cargo']}):
            original=copy.deepcopy(receipt);self.assertEqual(wt.command_view(receipt),(0,False));self.assertEqual(receipt,original)
        for bad in ({'exit_code':False,'timed_out':False},{'exit_code':0,'timed_out':0},{'exit_code':0},{'exitCode':0,'timedOut':False,'exit_code':0},{'exitCode':0,'timed_out':False}):
            with self.subTest(bad=bad),self.assertRaises(ValueError):wt.command_view(bad)
        outcome={'kind':'success','exit_code':0,'stdout':'{}','stderr':'','stdout_bytes':2,'stderr_bytes':0,'stdout_hash':hashlib.sha256(b'{}').hexdigest(),'stderr_hash':hashlib.sha256(b'').hexdigest()}
        original=copy.deepcopy(outcome);q.process(outcome);self.assertEqual(outcome,original)
    def test_windows_path_projection_is_operand_only_and_refuses_ambiguous_paths(self):
        self.assertTrue(wt.path_equal(r'D:\capture\run\token-guards\request.json','D:/capture/run/token-guards/request.json'))
        self.assertTrue(wt.path_equal(r'\\?\D:\capture\run\token-guards\request.json','D:/capture/run/token-guards/request.json'))
        self.assertFalse(wt.path_equal(r'D:\capture\foreign\request.json','D:/capture/run/request.json'))
        for bad in (r'\\?\UNC\server\share\request.json',r'\\?\GLOBALROOT\Device\request.json',r'\\.\D:\capture\request.json',r'\\server\share\request.json',r'D:\capture\..\foreign\request.json',r'D:\capture\name.\request.json',r'D:\capture\file:stream'):
            with self.subTest(path=bad),self.assertRaises(ValueError):wt.lexical_path(bad,True)
    def test_identity_namespaces_remain_distinct_and_alias_sources_refuse(self):
        self.assertEqual(q.key('//?/C:/repo/dir/../main.ts',False),'//?/c:/repo/main.ts')
        self.assertEqual(q.location('//?/C:/repo','//?/C:/repo/main.ts',False,'repository'),('c:/repo/main.ts',{'domain':'repository','path':'main.ts'}))
        self.assertEqual(q.location('//?/C:/repo','C:/repo/main.ts',False,'repository'),('c:/repo/main.ts',{'domain':'external','path':'/c:/repo/main.ts'}))
        self.assertEqual(q.location('//?/C:/repo','//?/D:/out.ts',False,'repository'),('d:/out.ts',{'domain':'external','path':'/?/d:/out.ts'}))
        for bad in ('//server/share/file.ts','//?/UNC/server/share/file.ts','//./C:/repo/file.ts','//?/1:/repo/file.ts','//?/C:relative','//?/C:/../../outside.ts','//?/C:/file:stream','//?/C:/file?name','//?/C:/file\x85name'):
            with self.subTest(path=bad),self.assertRaises(ValueError):q.key(bad,False)
        request={'cwd':'//?/C:/repo','sdk_directory':'/sdk/lib','case_sensitive':False,'files':{'//?/C:/repo/main.ts':'DEV'},'utf16_files':{},'raw_files':{}}
        sdk={'version':'DEV','archive_sha256':'DEV','files':{}}
        original=copy.deepcopy(request);q.logical_input(request,sdk);self.assertEqual(request,original)
        request['utf16_files']['C:/repo/MAIN.ts']=[1]
        with self.assertRaises(ValueError):q.logical_input(request,sdk)
    def test_explicit_layout_receipt_confinement_and_raw_hashes(self):
        root=HERE/'DEV-layout-fixture';root.mkdir(exist_ok=True);(root/'original-evidence').mkdir(exist_ok=True);supplement=root/'supplement-evidence';supplement.mkdir(exist_ok=True)
        native='D:/capture/run';manifest={'raw_root':str(root),'transport_locations':{'native_campaign_root':native,'supplement_evidence':{'path':str(supplement),'native_path':native+'/supplement-evidence'},'original_evidence':{'path':str(root/'original-evidence'),'native_path':native+'/original-evidence'}}}
        logical=wt.LogicalRoot(manifest);self.assertEqual(logical/'evidence',supplement.resolve());self.assertEqual(logical/'evidence/public/outcomes',supplement.resolve()/'public/outcomes');self.assertEqual(logical/'evidenceXYZ',root.resolve()/'evidenceXYZ')
        self.assertEqual(Path(logical),root.resolve())
        bad=copy.deepcopy(manifest);bad['transport_locations']['supplement_evidence']['path']=str(root/'foreign')
        with self.assertRaises(ValueError):wt.LogicalRoot(bad)
        with self.assertRaises(ValueError):logical/'../foreign'
        folder=logical/'evidence/public/invocations/DEV/input';folder.mkdir(parents=True,exist_ok=True);captured=native+'/supplement-evidence/public/invocations/DEV/input/ordinary-index-process.json'
        outcome={'kind':'success','exit_code':0,'stdout':'{"DEV":true}','stderr':'','stdout_bytes':12,'stderr_bytes':0,'stdout_hash':hashlib.sha256(b'{"DEV":true}').hexdigest(),'stderr_hash':hashlib.sha256(b'').hexdigest()}
        fixture={'artifact_path':r'D:\capture\run\frozen-binaries\probe.exe','sdk_path':r'D:\capture\run\sdk-input.json'}
        prepared={'case_root':native+'/supplement-evidence/public/invocations/DEV/input','repository_root':native+'/workspace'}
        frame={'argv':[fixture['artifact_path'],prepared['case_root'].replace('/','\\')+'\\ordinary-index-request.json',fixture['sdk_path']],'cwd':r'D:\capture\run\workspace','outcome':outcome}
        data=json.dumps(frame).encode();local=folder/'ordinary-index-process.json';local.write_bytes(data);receipt={'path':captured.replace('/','\\'),'native_c1':True,'frame_id':v.digest(frame),'process_outcome_id':v.digest(outcome)}
        wt.receipt_inventory(logical,folder,[receipt]);resolved=wt.receipt_path(logical,folder,receipt['path']);actual=json.loads(resolved.read_bytes());self.assertEqual(hashlib.sha256(local.read_bytes()).hexdigest(),hashlib.sha256(data).hexdigest());self.assertEqual(v.digest(actual),receipt['frame_id'])
        self.assertEqual(v.native_process_binding({'fixture':fixture},prepared,{local.name:actual},[receipt],'ordinary-index'),{'DEV':True});self.assertEqual(actual,frame)
        for field,value in [('path',r'D:\foreign\ordinary-index-process.json'),('path',r'D:\capture\run\supplement-evidence\public\invocations\DEV\other\ordinary-index-process.json')]:
            bad=dict(receipt,**{field:value})
            with self.subTest(value=value),self.assertRaises(ValueError):wt.receipt_inventory(logical,folder,[bad])
        with self.assertRaises(ValueError):wt.receipt_inventory(logical,folder,[receipt,dict(receipt)])
        bad=copy.deepcopy(actual);bad['argv'][0]=r'D:\foreign\probe.exe';br=dict(receipt,native_c1=False,frame_id=v.digest(bad))
        with self.assertRaises(ValueError):v.native_process_binding({'fixture':fixture},prepared,{local.name:bad},[br],'ordinary-index')
        bad=copy.deepcopy(actual);bad['argv'][1]=r'D:\foreign\ordinary-index-request.json';br=dict(receipt,frame_id=v.digest(bad))
        with self.assertRaises(ValueError):v.native_process_binding({'fixture':fixture},prepared,{local.name:bad},[br],'ordinary-index')

if __name__=='__main__':unittest.main(verbosity=2)
