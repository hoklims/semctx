# Next Windows evaluator preparation

Status: reader merge tested and bound to actual root native content protocol
`0474f9e1a051380ddbe11643c6fa109638e4d339905c26359721be9986ef1da1`.
The candidate clean Git HEAD remains a future explicit input. No query ran.

`prepared-modules/remaining_carriers.py` SHA:
`92c640da6decf363d0f122325811b9095dadecad6f226d109d7b4ad9cd7ea895`.
This combines native reader `e1b98db9…` with unchanged strict Windows transport
adaptations from immutable protocol `2bbb721a…`.

The native changes require `--discover-qualified-repository`, exact observation
scope `native_qualified_physical_discovery`, and original selected include/exclude
selectors for broad physical discovery eligibility. All raw frame/request/artifact
hashes, Windows path comparisons, explicit layout and namespace identity remain.

Five inherited Windows transport tests and two pure DEV context tests pass. The
latter execute the exact nested discovery function, accept Windows paths with
qualified physical mode and original selectors, and refuse coherently rehashed
ordinary mode, ordinary/retained contexts and broad selector substitutions.

After root freezes the actual final native source content, run:

```text
python -B build_package.py --source-package ACTUAL_FINAL_NATIVE_PACKAGE --source-protocol-sha256 ACTUAL_FINAL_SCOPE_MAP_SHA256 --source-manifest-sha256 ACTUAL_FINAL_MANIFEST_SHA256 --source-freeze-receipt ACTUAL_FINAL_FREEZE_RECEIPT --source-freeze-receipt-sha256 ACTUAL_FINAL_FREEZE_RECEIPT_SHA256
```

All arguments are mandatory. The tool checks actual package files and independently
supplied scope/manifest/receipt digests, the receipt file map and exact declared
source delta relative to its named known predecessor. Undeclared native module or
inventory changes fail. Every decoded scope field except source pins stays exactly
as the original:395/51 properties/supports,590 definitions,1386 frozen case files
and all expectations. Generated Windows reader bytes must equal this prepared
merge. A changed native reader requires a newly reviewed merge; no fallback.

Only that successful explicit command produces a new Windows protocol and ZIP
and reports their actual hashes. No query, caller, CI action, case, raw JSON, source
HEAD or expectation is changed. The old bundle2bbb remains untouched. No actual
native outcome, qualification or R0 claim is supplied by these DEV tests.
