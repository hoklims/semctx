"""Windows provenance comparisons only. Never rewrites raw DTOs or their hashes."""
import hashlib,json,re
from pathlib import Path
PROVENANCE=[]
VERIFIED_PROTOCOL=None

def require(value,reason):
    if not value:raise ValueError('WINDOWS_TRANSPORT: '+reason)
def record(kind,**fields):PROVENANCE.append({'kind':kind,**fields})
def source_head(raw):
    keys=[k for k in ('head','source_head') if k in raw];require(len(keys)==1,'one unambiguous source HEAD spelling required')
    value=raw[keys[0]];require(isinstance(value,str) and re.fullmatch('[0-9a-f]{40}',value) is not None,'actual exact source HEAD required')
    record('source_head_accessor',raw_key=keys[0],value=value);return value
def command_view(raw):
    codes=[k for k in ('exitCode','exit_code') if k in raw];times=[k for k in ('timedOut','timed_out') if k in raw]
    require(len(codes)==len(times)==1,'one unambiguous collector exit/timeout spelling required')
    require((codes[0],times[0]) in (('exitCode','timedOut'),('exit_code','timed_out')),'collector receipt mixes unsupported schemas')
    code=raw[codes[0]];timed=raw[times[0]];require(type(code) is int and type(timed) is bool,'collector exit integer and timeout boolean required')
    record('collector_receipt_accessor',exit_key=codes[0],timeout_key=times[0],exit_code=code,timed_out=timed)
    return code,timed
def source_pair(before,after,build,expected_head,runner_sha):
    require(before==after,'raw source snapshots differ')
    require(source_head(before)==source_head(after)==expected_head and before.get('status')=='','actual Windows source snapshot HEAD/status differs')
    require(source_head(build)==expected_head and build['source_before']==build['source_after'] and source_head(build['source_before'])==expected_head and build['source_before']['status']=='','build/source HEAD/status differs')
    require(before['files']==after['files']==build['source_before']['files']==build['source_after']['files'],'raw source/build file hashes differ')
    require(build['caller']['sha256']==runner_sha and before['files'].get('tools/rust-ts-r0/qualification/run_windows_milestone.py')==runner_sha,'actual Windows runner/caller source pin differs')

def lexical_path(value,windows_only=False):
    require(isinstance(value,str) and value and '\0' not in value,'path must be nonempty text')
    view=value.replace('\\','/')
    if view.startswith('//?/'):
        require(re.match(r'^//\?/[A-Za-z]:/',view) is not None,'only drive-local Win32 verbatim provenance paths are supported')
        original=view;view=view[4:];record('drive_verbatim_provenance_comparison',raw=value,comparison_view=view,raw_json_rewritten=False)
        require(original[4:]==view,'verbatim path projection changed content')
    require(not view.startswith('//'),'UNC/device path is unsupported; no guessed stripping')
    drive=re.match(r'^[A-Za-z]:/',view)
    require(bool(drive) or (not windows_only and view.startswith('/')),'absolute captured path required')
    tail=view[3:] if drive else view[1:]
    parts=tail.split('/')
    require(all(p and p not in ('.','..') and ':' not in p and not p.endswith((' ','.')) for p in parts),'ambiguous/traversing captured path')
    return view
def path_equal(left,right):
    a,b=lexical_path(left),lexical_path(right)
    record('path_operand_comparison',left_raw=left,right_raw=right,left_view=a,right_view=b,case_folded=False)
    return a==b
def argv_request_equal(actual,expected,index):
    require(isinstance(actual,list) and isinstance(expected,list) and len(actual)==len(expected),'native argv arity differs')
    return all(path_equal(a,b) if i==index else type(a)==type(b) and a==b for i,(a,b) in enumerate(zip(actual,expected,strict=True)))

def identity_key(value,sensitive):
    """Port verifier_absolute_key; preserve the drive-verbatim namespace."""
    require(type(value) is str and type(sensitive) is bool,'identity path/case mode required')
    path=value.replace('\\','/');verbatim=path.startswith('//?/')
    if path.startswith('//'):
        require(verbatim and re.match(r'^//\?/[A-Za-z]:/',path) is not None and not any(ord(c)<32 or 127<=ord(c)<=159 or c in ':?*' for c in path[7:]),'unsupported UNC/device identity')
    if verbatim:prefix,rest=path[:7],path[7:]
    elif path.startswith('/'):prefix,rest='/',path[1:]
    elif len(path)>=3 and path[1:3]==':/':prefix,rest=path[:3],path[3:]
    else:raise ValueError('WINDOWS_TRANSPORT: identity descriptor path must be absolute')
    parts=[]
    for part in rest.split('/'):
        if part in ('','.'):continue
        if part=='..':
            require(bool(parts),'identity path escapes native root');parts.pop()
        else:parts.append(part)
    key=prefix+'/'.join(parts)
    return key if sensitive else key.lower()

def identity_location(root,path,sensitive,domain):
    """Port namespace-sensitive locations and the separate alias collision key."""
    r=identity_key(root,sensitive);p=identity_key(path,sensitive)
    prefix=r.rstrip('/')+'/'
    location={'domain':domain,'path':'' if p==r else p[len(prefix):]} if p==r or p.startswith(prefix) else {'domain':'external','path':'/'+p.lstrip('/')}
    collision=p[4:] if p.startswith('//?/') else p
    record('logical_identity_path_view',root_raw=root,path_raw=path,canonical_namespace_path=p,collision_key=collision,location=location,raw_json_rewritten=False)
    return collision,location
def relative_parts(value):
    require(isinstance(value,str),'logical path must be text');parts=value.replace('\\','/').split('/')
    require(all(p and p not in ('.','..') and ':' not in p for p in parts),'logical path escapes explicit layout');return parts

class LogicalRoot:
    """Route an exact logical first component; __fspath__ keeps the actual root."""
    def __init__(self,manifest):
        self.actual=Path(manifest['raw_root']).resolve();locations=manifest['transport_locations']
        self.native=lexical_path(locations['native_campaign_root'],True).rstrip('/')
        self.supplement=Path(locations['supplement_evidence']['path']).resolve()
        original=Path(locations['original_evidence']['path']).resolve()
        require(self.supplement==self.actual/'supplement-evidence' and original==self.actual/'original-evidence','layout targets must equal declared Windows runner folders under actual raw root')
        require(path_equal(locations['supplement_evidence']['native_path'],self.native+'/supplement-evidence') and path_equal(locations['original_evidence']['native_path'],self.native+'/original-evidence'),'native/export folder relation differs')
        require(not (self.actual/'evidence').exists(),'ambiguous second evidence tree exists')
        record('logical_root_mapping',actual_root=str(self.actual),native_root=self.native,logical_evidence_target=str(self.supplement))
    def __truediv__(self,value):
        parts=relative_parts(str(value))
        return (self.supplement/Path(*parts[1:])) if parts[0]=='evidence' else self.actual/Path(*parts)
    def __fspath__(self):return str(self.actual)
    def __str__(self):return str(self.actual)
    def native_for(self,local):
        path=Path(local).resolve();require(path.is_relative_to(self.actual),'requested export path outside actual raw root')
        return self.native+'/'+path.relative_to(self.actual).as_posix()

def captured_file(root,captured,local):
    require(isinstance(root,LogicalRoot),'explicit Windows logical root required')
    actual=Path(local).resolve();expected=root.native_for(actual)
    require(path_equal(captured,expected),'captured path does not bind the exact exported file')
    return actual
def receipt_path(root,folder,captured):
    view=lexical_path(captured,True);parent,name=view.rsplit('/',1)
    require(path_equal(parent,root.native_for(folder)),'process receipt outside exact native invocation folder')
    require(name.endswith('.json') and name not in ('.','..'),'process receipt filename differs')
    local=captured_file(root,captured,Path(folder)/name)
    require(local.is_file() and not (Path(folder)/name).is_symlink(),'regular raw process frame required')
    record('receipt_export_location',captured_raw=captured,actual_export=str(local));return local
def receipt_inventory(root,folder,receipts):
    seen=set();names=set()
    for receipt in receipts:
        raw=receipt['path'];view=lexical_path(raw,True);name=view.rsplit('/',1)[-1]
        require(view not in seen and name.casefold() not in names,'duplicate/ambiguous process receipt location')
        receipt_path(root,folder,raw);seen.add(view);names.add(name.casefold())
def receipt_name(raw):return lexical_path(raw).rsplit('/',1)[-1]
def build_file(root,reference):
    view=lexical_path(reference['path'],True);name=view.rsplit('/',1)[-1]
    return captured_file(root,reference['path'],root.actual/name)
def logical_file(root,captured,logical):return captured_file(root,captured,root/logical)

def validate_fixture_paths(host,fixture):
    root=LogicalRoot(host)
    for kind in ('artifact','helper','transport_fixture','qualification_observer','sdk','legacy_identity_inputs'):
        raw=fixture[kind+'_path'];view=lexical_path(raw,True)
        require(view.startswith(root.native+'/'),'fixture path outside captured campaign root')
    require(fixture['platform']=='windows','actual Windows fixture platform required')
    return root

def validate_manifest_locations(host):
    root=LogicalRoot(host)
    require(Path(host['supplement']['evidence_root']).resolve()==root.supplement,'supplement evidence pin root differs from explicit layout')
    pins=[]
    for phase in ('original','supplement','source'):
        pins += [value for value in host[phase].values() if isinstance(value,dict) and 'path' in value]
    pins += list(host['artifact_files'].values())+list(host['native_compiler_identity'].values())+host['build_receipts']
    pins += [host[key] for key in ('token_family','legacy_identity_inputs') if key in host]
    for pin in pins:require(Path(pin['path']).resolve().is_relative_to(root.actual),'consumed manifest pin outside actual export root')
    return root

def verify_package(folder,expected):
    global VERIFIED_PROTOCOL
    path=Path(folder)/'windows-transport-protocol.json';raw=path.read_bytes()
    require(isinstance(expected,str) and hashlib.sha256(raw).hexdigest()==expected,'independent frozen Windows transport protocol pin differs')
    protocol=json.loads(raw)
    require(protocol.get('source_pin_freeze_supplied') is True,'DEV construction is not a frozen Windows evaluation protocol')
    for name,pin in protocol['package_files'].items():
        require(Path(name).name==name,'unsafe Windows package entry');data=(Path(folder)/name).read_bytes()
        require(hashlib.sha256(data).hexdigest()==pin['sha256'] and len(data)==pin['bytes'],'Windows evaluator bytes differ: '+name)
    VERIFIED_PROTOCOL=protocol
    return {'path':str(path),'sha256':expected,'scope_map_sha256':protocol['unchanged_scope_map_sha256']}
