"""Prepare this frozen two-file public case only after separate root stage approval."""
import argparse
import hashlib
import json
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True)
parser.add_argument('--lane',choices=['macos','linux'],required=True);args=parser.parse_args()
manifest=json.loads((HERE/'manifest.frozen.json').read_bytes())
for row in manifest['files']:
    value=(HERE/row['path']).read_bytes()
    assert len(value)==row['bytes'] and hashlib.sha256(value).hexdigest()==row['sha256']
root=args.root
assert root.is_absolute() and not root.exists()
root.mkdir(mode=0o700)
probe=root/'CaseProbe';probe.write_bytes(b'case')
sensitive=not (root/'caseprobe').exists();probe.unlink()
assert sensitive is (args.lane=='linux')
repo=root/'repo';repo.mkdir()
files={}
for name in ('entry.ts','target.ts'):
    data=(HERE/'fixture/repo'/name).read_bytes();target=repo/name;target.write_bytes(data)
    files[target.as_posix()]=data.decode()
sdk=json.loads((HERE/'sdk.frozen.json').read_bytes());sdk_dir=root/'sdk/lib';sdk_dir.mkdir(parents=True)
mapped={}
for path,text in sdk['files'].items():
    name=path.replace('\\','/').rsplit('/',1)[-1]
    assert re.fullmatch('[A-Za-z0-9_.-]+',name)
    target=sdk_dir/name;assert not target.exists();target.write_bytes(text.encode());mapped[target.as_posix()]=text
sdk['files']=mapped
request=json.loads((HERE/'request.local.json').read_bytes())
request.update(cwd=repo.as_posix(),sdk_directory=sdk_dir.as_posix(),case_sensitive=sensitive,files=files,roots=list(files))
for name,value in [('request.json',request),('sdk.json',sdk)]:
    (root/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
pins={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}
result={'kind':'PUBLIC_NAMED_DEFAULT_INPUT_PREPARATION_NO_CANDIDATE','lane':args.lane,'root':str(root),
        'manifest_sha256':hashlib.sha256((HERE/'manifest.frozen.json').read_bytes()).hexdigest(),'files':pins,
        'candidate_queries':0,'candidate_builds':0,'git_commits':0,'execution_authorized':False}
(root/'input-freeze.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
