"""Materialize one public named-default reference; no candidate/host/Git call."""
import hashlib
import json
from pathlib import Path
import shutil

HERE=Path(__file__).resolve().parent
root=HERE/'fixture/repo'
sdk_source=HERE.parent/'t00-public-failure-witnesses-v1/native-request-examples-v3/sdk.json'
shutil.copyfile(sdk_source,HERE/'sdk.frozen.json')
sdk=json.loads(sdk_source.read_bytes())
assert sdk['version']=='5.9.3' and len(sdk['files'])==100
sdk_dirs={p.replace('\\','/').rsplit('/',1)[0] for p in sdk['files']}
assert len(sdk_dirs)==1
paths=[root/'entry.ts',root/'target.ts']
request={'id':'PUBLIC-NAMED-DEFAULT-CALL','cwd':root.as_posix(),'sdk_directory':sdk_dirs.pop(),'case_sensitive':False,
         'roots':[p.as_posix() for p in paths],'files':{p.as_posix():p.read_text() for p in paths},
         'options':{'target':'ES2022','module':'ESNext','moduleResolution':'Bundler','allowJs':True,'jsx':'Preserve','skipLibCheck':True,'noEmit':True,'strict':False},
         'retained':True,'qualified':True,'roles':{},'selection':{},'disabled':[],'utf16_files':{},'raw_files':{}}
target=HERE/'request.local.json'
with target.open('x',encoding='utf-8') as out:json.dump(request,out,indent=2);out.write('\n')
print(json.dumps({'request_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'candidate_queries':0,'host_actions':0}))
