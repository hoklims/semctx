# Named default export: two correct, distinct names

This is one new public case with two short source files. No private case,
identifier, mapping, expectation or historical/private reader was read. No
candidate, remote host, staging, build or Git commit was invoked.

The first and only TypeScript reference attempt established the requested
distinction. `target.ts` declares `export default function target(...)`; the
entry imports it with `import target from './target'` and calls `target(2)`.

The actual TypeScript 5.9.3 / Bun 1.4.3 checker records:

- raw local import alias name: `target`;
- symbol after `getAliasedSymbol`: `default`;
- resolved value declaration: `FunctionDeclaration` in `target.ts`.

The actual production `extractTypeScript` call records canonical callee name
`target`, canonical target coordinate `target`, and target source `target.ts`.
Thus the resolved checker name differs from **both** canonical callee name and
its final target segment. This is not the previously explored difference
between a short method name and a qualified path.

The native public source explicitly resolves import aliases before writing
both the top-level Call checker name and its first provenance name. Its ordinary
target resolver instead prefers a declaration's syntactic scope name. The
frozen source excerpts document these distinct mechanisms. This predicts a
native-facing checker name without pretending that C1 has been executed.

The reference used production blob `2400cdd94c0903195df82c2b2c387bcbaa1513b0`
(physical SHA256 `9e025956b492b77cd13c59e9b5196c76506367db484180f28824ccd508665d7f`).
The separate checker Program uses exact captured source and 100 SDK files,
validates their physical bytes, records 65 reads, and reports zero diagnostics.
The one CallExpression has UTF16 range `[65,74]`. The real command was
`C:/Users/Hokli/.bun/bin/bun.exe work/public-callable-name-witness/reference.cjs`,
exit 0; its structured output is `baseline.actual.json`. The tool response holds
the execution summary; no separate raw process log was created.

The reader validates request/input/artifact/SDK identity, both source roots,
raw and provenance Call spans, exact resolved declaration file/kind/ranges,
declaration inventory, source digests/read bindings and each native symbol DTO
hash. It compares checker name and canonical target against their own reference
fields. One positive synthetic control and 17 falsifications pass; these are
reader controls, not native evidence.

`native-plan.disabled.json` proposes one bounded native query per host using the
parent's actual `96fedbbe` preparation. Separate staging/preflight and root
execution authority are still required. Native unsupported or failing contexts
must be preserved. An actual historical-reader RED remains unestablished until
the unchanged helper reads the exact future native capture. No admission,
ownership, qualification or global absence is inferred.
