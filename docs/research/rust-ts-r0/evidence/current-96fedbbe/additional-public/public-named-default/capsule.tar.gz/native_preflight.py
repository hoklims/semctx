"""Metadata only: verify the frozen public fixture and current native bindings."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import public96_preflight as prepared
import read_public


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_bytes())


def save(path,value):
    with Path(path).open('x',encoding='utf-8') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')


def package_check():
    freeze=load(HERE/'STAGING-FREEZE.json')
    for row in freeze['files']:
        path=HERE/row['path']
        prepared.need(sha(path)==row['sha256'] and path.stat().st_size==row['bytes'],'staging capsule differs: '+row['path'])
    prepared.need(sha(HERE/'manifest.frozen.json')=='111ec56f03c516b2388f40ebae8073a2179ffbd4215c377f85376cfd20f7e38d','original public freeze differs')
    return load(HERE/'native-bindings.actual.disabled.json')


def stable_inputs(lane,root):
    binding=package_check()['lanes'][lane]
    environment=prepared.prepared_environment(root,lane,binding)
    frozen=load(root/'input-freeze.json')
    prepared.need(frozen['lane']==lane and frozen['candidate_queries']==0 and frozen['execution_authorized'] is False,'input freeze contaminated')
    for rel,digest in frozen['files'].items():
        prepared.need(sha(root/rel)==digest,'physical input drift: '+rel)
    request=load(root/'request.json');sdk=load(root/'sdk.json')
    read_public.check_inputs(lane,request,sdk)
    actual_sdk={p.as_posix() for p in Path(request['sdk_directory']).rglob('*') if p.is_file()}
    prepared.need(actual_sdk==set(sdk['files']) and len(actual_sdk)==100,'physical SDK inventory differs')
    prepared.need({p.relative_to(root/'repo').as_posix() for p in (root/'repo').rglob('*') if p.is_file()}=={'entry.ts','target.ts'},'source inventory differs')
    return {'environment':environment,'inputFreezeSha256':sha(root/'input-freeze.json'),
            'requestSha256':sha(root/'request.json'),'sdkDescriptorSha256':sha(root/'sdk.json'),
            'physicalSdkFiles':100,'physicalSourceFiles':2},binding


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--lane',choices=['macos','linux'],required=True)
    parser.add_argument('--root',type=Path,required=True);args=parser.parse_args()
    binding=package_check()['lanes'][args.lane]
    plan=load(HERE/'native-plan.disabled.json')['platforms'][args.lane]
    prepared.need(args.root.as_posix()==plan['proposed_input_root'] and not args.root.exists(),'exclusive root differs/exists')
    before=prepared.prepared_environment(HERE,args.lane,binding)
    argv=[binding['python_path'],str(HERE/'materialize_native.py'),'--root',str(args.root),'--lane',args.lane]
    result=subprocess.run(argv,capture_output=True,timeout=120)
    receipt={'argv':argv,'exit_code':result.returncode,'stdout':result.stdout.decode('utf-8','replace'),
             'stderr':result.stderr.decode('utf-8','replace'),'candidate_queries':0}
    save(HERE/('materialize-'+args.lane+'.process.json'),receipt)
    prepared.need(result.returncode==0,'metadata materialization failed; do not rerun occupied root')
    after,_=stable_inputs(args.lane,args.root)
    prepared.need(after['environment']==before,'prepared native environment changed during metadata preparation')
    output={'schema':1,'state':'PUBLIC_NAMED_DEFAULT_NATIVE_PREFLIGHT_NO_C1','lane':args.lane,
            'source_head':prepared.HEAD,'protocol_sha256':'309fbbd74141eaa0d383f340247802cd283c892a6048902adaf29e9e6c18c4c3',
            'manifest_sha256':sha(HERE/'manifest.frozen.json'),'staging_freeze_sha256':sha(HERE/'STAGING-FREEZE.json'),
            'preflight':after,'candidate_queries':0,'candidate_builds':0,'git_commits':0,'execution_authorized':False,
            'qualification_credit':0,'R0_decision':None}
    path=args.root/'METADATA-PREFLIGHT-RECEIPT.json';save(path,output)
    print(json.dumps({'lane':args.lane,'preflight_receipt_sha256':sha(path),'input_freeze_sha256':after['inputFreezeSha256'],
                      'execution_runner_sha256':sha(HERE/'execute_native_v2.py'),'candidate_queries':0}))


if __name__=='__main__':main()
