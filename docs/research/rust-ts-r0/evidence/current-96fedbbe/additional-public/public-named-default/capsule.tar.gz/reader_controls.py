"""Finite synthetic reader controls, not native evidence or an old-reader RED."""
import copy
import json
from pathlib import Path
import read_public as reader
from identity_scope_reader import digest,digest_bytes,logical_input

HERE=Path(__file__).resolve().parent
request=copy.deepcopy(reader.LOCAL);sdk=copy.deepcopy(reader.SDK);oracle=reader.EXPECTED
sources={reader.baseline_relative(p):(p,t) for p,t in request['files'].items()}


def node(ref):
    rel=reader.baseline_relative(ref['file']);p,t=sources[rel]
    return {'file':p,'kind':ref['kind'],'sourceDigest':digest_bytes(t.encode()),'defaultLibrary':ref['defaultLibrary'],
            'startUtf16':ref['startUtf16'],'endUtf16':ref['endUtf16']}


def source_node(rel):
    p,t=sources[rel]
    return {'file':p,'kind':'SourceFile','sourceDigest':digest_bytes(t.encode()),'defaultLibrary':False,
            'startUtf16':0,'endUtf16':len(t.encode('utf-16-le'))//2}


symbol={'name':oracle['resolved_checker_name'],'valueDeclaration':node(oracle['value_declaration']),
        'declarations':[node(d) for d in oracle['declarations']]}
symbol['identity']=digest(symbol)
call={'call':node(oracle['call']),'stoppedAtCycle':False,'originChain':[
    {'expression':node(oracle['expression']),'symbol':symbol,'followedImmutableInitializer':False}]}
read_bindings=[{'file':p,'sourceDigest':digest_bytes(t.encode()),'defaultLibrary':False} for p,t in sources.values()]
subjects=[{'path':rel,'outcome':'analyzed','callProvenanceObservation':{
    'executed':True,'source':source_node(rel),'calls':[call] if rel=='entry.ts' else [],'readBindings':read_bindings}}
          for rel in ('entry.ts','target.ts')]
observed={'complete':True,'global_admission_inferred':False,'request':request['id'],'request_id':digest(request),
          'input_manifest_id':digest(logical_input(request,sdk)),'producer_artifact_id':'sha256:'+reader.ARTIFACT['macos'],
          'sdk_version':'5.9.3','ambient_native_case_sensitive':False,'subjects':subjects,
          'capture_probes':[{'operation':'read_file','path':p,'found':True,'content_id':digest_bytes(t.encode())} for p,t in sources.values()],
          'calls':[{'file':sources['entry.ts'][0],'start_utf16':oracle['call']['startUtf16'],'end_utf16':oracle['call']['endUtf16'],
                    'symbol_name':oracle['resolved_checker_name'],'declarations':[
                        {'file':d['file'],'start_utf16':d['startUtf16'],'end_utf16':d['endUtf16'],'default_library':d['defaultLibrary']}
                        for d in oracle['declarations']]}],
          'raw_extraction':{'calls':[oracle['canonical_call']]}}
positive=reader.read('macos',request,sdk,observed,physical=False)
assert positive['resolved_checker_name']=='default' and positive['canonical_callee_name']==positive['canonical_target']=='target'


def change(path,value):
    def mutate(data):
        owner=data
        for p in path[:-1]:owner=owner[p]
        owner[path[-1]]=value
    return mutate


prefix=['subjects',0,'callProvenanceObservation','calls',0,'originChain',0,'symbol']
mutants={
    'raw_checker_replaced_with_lexical_alias':change(['calls',0,'symbol_name'],'target'),
    'resolved_checker_replaced_with_canonical_name':change(prefix+['name'],'target'),
    'canonical_callee_replaced_with_checker_name':change(['raw_extraction','calls',0,'calleeName'],'default'),
    'canonical_target_replaced_with_checker_name':change(['raw_extraction','calls',0,'calleeSymbolPath'],'default'),
    'value_declaration_wrong_kind':change(prefix+['valueDeclaration','kind'],'VariableDeclaration'),
    'value_declaration_wrong_owner':change(prefix+['valueDeclaration','file'],sources['entry.ts'][0]),
    'declaration_inventory_removed':change(prefix+['declarations'],[]),
    'raw_declaration_wrong_owner':change(['calls',0,'declarations',0,'file'],sources['entry.ts'][0]),
    'boolean_call_coordinate':change(['calls',0,'start_utf16'],True),
    'other_call_span':change(['calls',0,'end_utf16'],oracle['call']['endUtf16']+1),
    'native_hash_replaced_by_canonical_id':change(prefix+['identity'],'sym:function:target.ts:target'),
    'foreign_input_id':change(['input_manifest_id'],'sha256:'+'0'*64),
    'foreign_artifact':change(['producer_artifact_id'],'sha256:'+'0'*64),
    'foreign_sdk_version':change(['sdk_version'],'7.1.0-dev'),
    'global_admission_forged':change(['global_admission_inferred'],True),
    'canonical_calls_removed':change(['raw_extraction','calls'],[]),
    'entry_provenance_removed':change(['subjects',0,'callProvenanceObservation','calls'],[]),
}
results=[]
for name,mutate in mutants.items():
    actual=copy.deepcopy(observed);mutate(actual)
    if name.startswith(('resolved_checker','value_declaration','declaration_inventory')):
        value=actual['subjects'][0]['callProvenanceObservation']['calls'][0]['originChain'][0]['symbol']
        value['identity']=digest({k:v for k,v in value.items() if k!='identity'})
    try:reader.read('macos',request,sdk,actual,physical=False)
    except (ValueError,KeyError,TypeError,IndexError) as error:results.append({'name':name,'rejected':True,'error':str(error)})
    else:raise AssertionError('falsification accepted: '+name)
result={'kind':'SYNTHETIC_PUBLIC_NAMED_DEFAULT_READER_CONTROLS_NOT_NATIVE','positive_controls':1,
        'negative_controls':len(results),'results':results,'reference_attempts':1,'candidate_queries':0,'host_actions':0,
        'old_reader_red_established':False,'qualification_credit':0}
with (HERE/'reader-controls.json').open('x',encoding='utf-8') as out:json.dump(result,out,indent=2);out.write('\n')
print(json.dumps({'positive_controls':1,'negative_controls':len(results),'candidate_queries':0}))
