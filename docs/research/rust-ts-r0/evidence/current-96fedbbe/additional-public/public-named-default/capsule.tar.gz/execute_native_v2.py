"""One bounded native public query; requires a separately authored root GO."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

import native_preflight as preflight
import read_public

HERE=Path(__file__).resolve().parent


def validate_root(root, expected):
    preflight.prepared.need(root.is_absolute() and root.as_posix()==expected.as_posix(), "exact frozen input root differs")
    preflight.prepared.need(not root.is_symlink() and root.resolve(strict=True)==root, "input root alias differs")


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--lane',choices=['macos','linux'],required=True)
    parser.add_argument('--root',type=Path,required=True);parser.add_argument('--go',type=Path,required=True)
    parser.add_argument('--go-sha256',required=True);args=parser.parse_args()
    frozen_root=Path(preflight.load(HERE/"native-plan.disabled.json")["platforms"][args.lane]["proposed_input_root"])
    validate_root(args.root,frozen_root)
    successor=preflight.load(HERE/"EXECUTION-FREEZE-V2.json")
    preflight.prepared.need(successor["execution_runner_sha256"]==preflight.sha(__file__),"execution successor differs")
    before,binding=preflight.stable_inputs(args.lane,args.root)
    receipt=args.root/'METADATA-PREFLIGHT-RECEIPT.json'
    prepared=preflight.load(receipt)
    preflight.prepared.need(before==prepared['preflight'],'actual frozen preflight changed')
    # Read and parse root authority once, before creating a query claim/output.
    raw=args.go.read_bytes()
    preflight.prepared.need(hashlib.sha256(raw).hexdigest()==args.go_sha256,'root GO byte pin differs')
    go=json.loads(raw)
    expected={'schema':1,'explicit_root_go':True,'lane':args.lane,'source_head':preflight.prepared.HEAD,
              'metadata_preflight_sha256':preflight.sha(receipt),'input_freeze_sha256':before['inputFreezeSha256'],
              'staging_freeze_sha256':preflight.sha(HERE/'STAGING-FREEZE.json'),'execution_runner_sha256':preflight.sha(__file__),
              'candidate_sha256':binding['artifact_sha256'],'max_candidate_queries':1,'attempt_limit':1,
              'timeout_ms':20000,'output_cap_bytes_per_stream':8388608,'candidate_builds':0,'qualification_credit':0,'R0_decision':None}
    expected.update(input_root=str(args.root),execution_freeze_sha256=preflight.sha(HERE/"EXECUTION-FREEZE-V2.json"))
    preflight.prepared.need(type(go) is dict and set(go)==set(expected),'root GO exact key set differs')
    for key,value in expected.items():
        preflight.prepared.need(type(go[key]) is type(value) and go[key]==value,'typed root GO differs: '+key)
    evidence=args.root/'evidence';evidence.mkdir()
    query_attempted=False;actual_queries=None;state='FAILED';failure=None
    try:
        request=preflight.load(args.root/'request.json');sdk=preflight.load(args.root/'sdk.json')
        input_pins=preflight.load(args.root/'input-freeze.json')['files']
        pins=[*before['environment']['pins'].values()]
        pins.extend({'path':str(args.root/rel),'sha256':digest} for rel,digest in input_pins.items())
        pins.extend({'path':binding[field],'sha256':binding[pin]} for field,pin in [
            ('build_environment_path','build_environment_sha256'),('fixture_path','fixture_sha256'),
            ('sdk_container_path','sdk_container_sha256'),('source_snapshot_path','source_snapshot_sha256')])
        spec={'schema':1,'execution_authorized':True,
              'argv':[binding['artifact_path'],str(args.root/'request.json'),str(args.root/'sdk.json')],
              'cwd':str(args.root/'repo'),'helper':binding['helper_path'],'timeout_ms':20000,'output_cap':8388608,
              'pins':pins,'candidate_query':True}
        spec_path=evidence/'direct.spec.json';preflight.save(spec_path,spec)
        env=os.environ.copy();env.update(GOPORT_LIB_PARSE_SNAPSHOT='0',GOPORT_LIB_SNAPSHOT='0',
            GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',GIT_TERMINAL_PROMPT='0',PYTHONDONTWRITEBYTECODE='1')
        argv=[binding['generic_caller_path'],str(spec_path),str(evidence/'direct')]
        query_attempted=True
        process=subprocess.run(argv,cwd=args.root,env=env,capture_output=True,timeout=45)
        preflight.save(evidence/'caller.json',{'argv':argv,'exit_code':process.returncode,
            'stdout':process.stdout.decode('utf-8','replace'),'stderr':process.stderr.decode('utf-8','replace')})
        preflight.prepared.need(process.returncode==0,'bounded caller failed; no retry')
        outcome=preflight.load(evidence/'direct/process-outcome.json');actual_queries=1
        for stream in ('stdout','stderr'):
            data=(evidence/'direct'/(stream+'.raw')).read_bytes()
            preflight.prepared.need(len(data)==outcome[stream+'_bytes'] and hashlib.sha256(data).hexdigest()==outcome[stream+'_hash'],'actual stream identity differs')
            preflight.prepared.need(len(data)<=8388608,'actual stream exceeded cap')
        preflight.prepared.need(outcome['kind']=='success' and outcome['exit_code']==0,'direct candidate outcome non-success; preserve and stop')
        observed=json.loads((evidence/'direct/stdout.raw').read_bytes())
        result=read_public.read(args.lane,request,sdk,observed)
        preflight.save(evidence/'adjudication.json',result)
        state='PUBLIC_NAMED_DEFAULT_COMPONENT_PASS'
    except Exception as error:
        failure=str(error)
        raise
    finally:
        postflight_error=None
        try:
            after,_=preflight.stable_inputs(args.lane,args.root)
            preflight.prepared.need(after==before,'native/input postflight changed')
            postflight_ok=True
        except Exception as error:
            postflight_ok=False;postflight_error=str(error)
        result={'schema':1,'state':state,'lane':args.lane,'source_head':preflight.prepared.HEAD,
                'query_attempted':query_attempted,'candidate_queries':actual_queries,'attempt_limit':1,'retries':0,'candidate_builds':0,
                'postflight_ok':postflight_ok,'postflight_error':postflight_error,'failure':failure,
                'root_go_sha256':args.go_sha256,'metadata_preflight_sha256':preflight.sha(receipt),
                'qualification_credit':0,'R0_decision':None}
        preflight.save(evidence/'RESULT.json',result)
        if not postflight_ok:raise RuntimeError('public native postflight failed: '+str(postflight_error))
    print(json.dumps(result))


if __name__=='__main__':main()
