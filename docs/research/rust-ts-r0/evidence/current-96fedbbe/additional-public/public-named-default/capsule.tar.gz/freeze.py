"""Seal the one successful public reference before candidate or remote actions."""
import ast
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
head='96fedbbe14e8585ae1c89e2656604bf5ecabf2c3'
prepared=WORK/'native-96fedbbe-prepared-export'
summary=prepared/'prepared-two-os-summary.json'
assert hashlib.sha256(summary.read_bytes()).hexdigest()=='cc4dc66acdc64eb1f5e7e1d05158475126757663ba84e282f87ee1ab8fb2902d'
baseline=json.loads((HERE/'baseline.actual.json').read_bytes())
assert baseline['reference_attempt']==1 and baseline['requestedDistinctionObserved'] is True and baseline['candidateQueries']==0
authority=json.loads((HERE/'source-authority.json').read_bytes())
for source,start,end,label,reason in [
    (Path('C:/maintenence/semctx.codex-t00-physical-20261022/tools/rust-ts-r0/src/ordinary.rs'),879,944,'authority-resolve_target.rs.txt','native target prefers declaration scope_name over checker symbol name'),
    (Path('C:/maintenence/semctx.codex-t00-review-20261021/packages/ts-analyzer/src/ts-symbols.ts'),1537,1564,'authority-ts-resolveCallTarget.txt','TS target resolves aliases then prefers declaration scopeNameOf')]:
    text=''.join(source.read_text().splitlines(keepends=True)[start-1:end])
    path=HERE/label
    with path.open('x',encoding='utf-8') as output:output.write(text)
    authority.append({'source_path':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
                      'start_line':start,'end_line':end,'excerpt':label,'excerpt_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'reason':reason})
# This authority draft has not been frozen previously.
(HERE/'source-authority.json').write_text(json.dumps(authority,indent=2)+'\n')
platforms={}
for lane in ('macos','linux'):
    path=prepared/('prepared-'+lane)/'fixture.disabled.json';fixture=json.loads(path.read_bytes())
    assert fixture['source_head']==head and fixture['candidate_execution_authorized'] is False
    base='/Users/hokli/semctx-t00-build-evidence-20261021' if lane=='macos' else '/work/evidence'
    root=base+'/public-callable-name-witness-96fedbbe-inputs'
    platforms[lane]={'candidate_path':fixture['artifact_path'],'candidate_sha256':fixture['artifact_sha256'],
                     'helper_path':fixture['helper_path'],'helper_sha256':fixture['helper_sha256'],
                     'build_environment_sha256':fixture['build_environment_sha256'],
                     'prepared_fixture_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                     'case_sensitive':lane=='linux','proposed_input_root':root,
                     'proposed_tools_root':base+'/public-callable-name-witness-96fedbbe-tools',
                     'candidate_argv':[fixture['artifact_path'],root+'/request.json',root+'/sdk.json'],
                     'candidate_phase_count':1,'attempt_limit':1,'timeout_ms':20000,'output_cap_bytes_per_stream':8388608,
                     'execution_authorized':False,'native_inputs_exist_claimed':False}
plan={'kind':'DISABLED_PUBLIC_NAMED_DEFAULT_ONE_QUERY_PER_HOST_PLAN','source_head':head,
      'protocol_sha256':'309fbbd74141eaa0d383f340247802cd283c892a6048902adaf29e9e6c18c4c3',
      'prepared_summary_sha256':hashlib.sha256(summary.read_bytes()).hexdigest(),'platforms':platforms,
      'requirements':['Separate root staging approval and concrete preflight before any query authority.',
                      'Bind exact source227, five prepared binaries, build/SDK container, native case and two physical source files/100 SDK files.',
                      'Exactly one direct C1 phase per host under root-bound one-shot GO,20s/8MiB per stream, no retry/build.',
                      'Keep actual raw checker name and first provenance name separate from canonical calleeName and declaration target.',
                      'Retain actual failure or unsupported context; source/SDK/request/artifact postflight in finally.',
                      'Linux uses existing network-none501:20/source-RO container with owned wake alive before every Docker API.'],
      'candidate_queries':0,'candidate_builds':0,'host_actions':0,'git_commits':0,'execution_authorized':False,
      'old_reader_red_established':False,'qualification_credit':0,'R0_decision':None}
with (HERE/'native-plan.disabled.json').open('x',encoding='utf-8') as out:json.dump(plan,out,indent=2);out.write('\n')
for p in HERE.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
files=[]
for p in sorted(HERE.rglob('*')):
    if p.is_file() and '__pycache__' not in p.parts and p.name!='manifest.frozen.json':
        raw=p.read_bytes();files.append({'path':p.relative_to(HERE).as_posix(),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
value={'schema':1,'kind':'PUBLIC_NAMED_DEFAULT_CALL_PREQUERY_FREEZE','source_head_at_freeze':head,
       'files':files,'reference_attempts':1,'baseline_sha256':hashlib.sha256((HERE/'baseline.actual.json').read_bytes()).hexdigest(),
       'oracle_sha256':hashlib.sha256((HERE/'expected-oracle.json').read_bytes()).hexdigest(),
       'reader_sha256':hashlib.sha256((HERE/'read_public.py').read_bytes()).hexdigest(),
       'reader_controls_sha256':hashlib.sha256((HERE/'reader-controls.json').read_bytes()).hexdigest(),
       'candidate_queries':0,'candidate_builds':0,'host_actions':0,'git_commits':0,'execution_authorized':False,
       'old_reader_red_established':False,'qualification_credit':0,'R0_decision':None}
target=HERE/'manifest.frozen.json'
with target.open('x',encoding='utf-8') as out:json.dump(value,out,indent=2);out.write('\n')
print(json.dumps({'manifest_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'files':len(files),
                  'baseline_sha256':value['baseline_sha256'],'oracle_sha256':value['oracle_sha256'],'reader_sha256':value['reader_sha256'],
                  'reference_attempts':1,'candidate_queries':0,'host_actions':0}))
