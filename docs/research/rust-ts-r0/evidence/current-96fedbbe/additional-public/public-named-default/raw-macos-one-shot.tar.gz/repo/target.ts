export default function target(value: number) { return value + 1; }
