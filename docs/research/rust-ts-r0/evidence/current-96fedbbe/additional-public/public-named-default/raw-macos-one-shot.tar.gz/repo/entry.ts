import target from './target';
export function invoke() { return target(2); }
