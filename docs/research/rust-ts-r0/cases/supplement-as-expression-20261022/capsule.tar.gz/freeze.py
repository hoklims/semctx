"""Freeze the independent public contrast before any candidate invocation."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
head = '96fedbbe14e8585ae1c89e2656604bf5ecabf2c3'
prepared = WORK / 'native-96fedbbe-prepared-export'
summary_path = prepared / 'prepared-two-os-summary.json'
assert hashlib.sha256(summary_path.read_bytes()).hexdigest() == 'cc4dc66acdc64eb1f5e7e1d05158475126757663ba84e282f87ee1ab8fb2902d'
summary = json.loads(summary_path.read_bytes())
assert summary['source_head'] == head
platforms = {}
for lane in ('macos', 'linux'):
    fixture_path = prepared / ('prepared-' + lane) / 'fixture.disabled.json'
    fixture = json.loads(fixture_path.read_bytes())
    assert fixture['source_head'] == head and fixture['source_clean'] is True
    assert fixture['candidate_execution_authorized'] is False
    assert fixture['artifact_sha256'] == summary['lanes'][lane]['producer_sha256']
    base = '/Users/hokli/semctx-t00-build-evidence-20261021' if lane == 'macos' else '/work/evidence'
    inputs = base + '/public-as-expression-96fedbbe-inputs'
    platforms[lane] = {'case_sensitive': lane == 'linux', 'candidate_path': fixture['artifact_path'],
                       'candidate_sha256': fixture['artifact_sha256'], 'helper_path': fixture['helper_path'],
                       'helper_sha256': fixture['helper_sha256'],
                       'prepared_fixture_sha256': hashlib.sha256(fixture_path.read_bytes()).hexdigest(),
                       'build_environment_sha256': fixture['build_environment_sha256'],
                       'proposed_tools_root': base + '/public-as-expression-96fedbbe-tools',
                       'proposed_input_root': inputs, 'proposed_evidence_root': base + '/public-as-expression-96fedbbe-evidence',
                       'contexts': [{'context': c, 'argv': [fixture['artifact_path'], inputs + '/request.' + c + '.json', inputs + '/sdk.json'],
                                     'attempts': 1, 'timeout_ms': 20000, 'output_cap_bytes_per_stream': 8388608}
                                    for c in ('legacy', 'retained')],
                       'native_inputs_exist_claimed': False, 'execution_authorized': False}
plan = {'kind': 'DISABLED_PUBLIC_AS_EXPRESSION_TWO_CONTEXTS_PER_HOST_PLAN', 'source_head': head,
        'protocol_sha256': '309fbbd74141eaa0d383f340247802cd283c892a6048902adaf29e9e6c18c4c3',
        'prepared_summary_sha256': hashlib.sha256(summary_path.read_bytes()).hexdigest(), 'platforms': platforms,
        'required_preflight': ['verify complete frozen capsule and both source-96 native metadata snapshots',
                              'verify source HEAD, all 227 source pins, five binary/tool pins, build and SDK identities',
                              'create two exact requests against one source/SDK and measure actual native case mode',
                              'validate both requests physically with read_public.py before separate root GO'],
        'required_execution': ['one direct legacy call and one direct retained call per host, preserve actual outcome/raw streams',
                               'read each exact stdout with its own explicit context and frozen request/SDK',
                               'finally authenticate all source, binary, build, request, source and SDK identities even on failure'],
        'linux_runtime': 'Existing network-none container user501:20/source read-only; owned caffeinate alive before every Docker API and stop only owned assertion.',
        'candidate_queries': 0, 'candidate_builds': 0, 'host_actions': 0, 'execution_authorized': False,
        'qualification_credit': 0, 'R0_decision': None}
with (HERE / 'native-plan.disabled.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(plan, stream, indent=2)
    stream.write('\n')
for path in HERE.glob('*.py'):
    ast.parse(path.read_text(), filename=str(path))
files = []
for path in sorted(HERE.rglob('*')):
    if path.is_file() and '__pycache__' not in path.parts and path.name != 'manifest.frozen.json':
        raw = path.read_bytes()
        files.append({'path': path.relative_to(HERE).as_posix(), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)})
manifest = {'schema': 1, 'kind': 'PUBLIC_AS_EXPRESSION_INDEPENDENT_PREQUERY_FREEZE', 'source_head_at_freeze': head,
            'files': files, 'baseline_sha256': hashlib.sha256((HERE / 'baseline.actual.json').read_bytes()).hexdigest(),
            'oracle_sha256': hashlib.sha256((HERE / 'expected-oracle.json').read_bytes()).hexdigest(),
            'reader_sha256': hashlib.sha256((HERE / 'read_public.py').read_bytes()).hexdigest(),
            'controls_sha256': hashlib.sha256((HERE / 'reader-controls.json').read_bytes()).hexdigest(),
            'candidate_queries': 0, 'candidate_builds': 0, 'host_actions': 0, 'git_commits': 0,
            'qualification_credit': 0, 'R0_decision': None}
with (HERE / 'manifest.frozen.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(manifest, stream, indent=2)
    stream.write('\n')
print(json.dumps({'manifest_sha256': hashlib.sha256((HERE / 'manifest.frozen.json').read_bytes()).hexdigest(),
                  'files': len(files), 'baseline_sha256': manifest['baseline_sha256'],
                  'oracle_sha256': manifest['oracle_sha256'], 'reader_sha256': manifest['reader_sha256'],
                  'controls_sha256': manifest['controls_sha256'], 'candidate_queries': 0, 'host_actions': 0}))
