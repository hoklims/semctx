"""One public source, two explicit contexts; no candidate or host execution."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
REPO = Path('C:/maintenence/semctx.codex-t00-physical-20261022')
BASE = '3e94997fcbefa72ad4d49b2cad180ee79b7c0a9b'
root = HERE / 'fixture/repo'
root.mkdir(parents=True, exist_ok=False)
source = root / 'entry.ts'
text = 'export function helper() { return 1; }\nexport function caller() { return ((helper as () => number))(); }\n'
source.write_text(text, encoding='utf-8', newline='\n')
sdk_path = HERE.parent / 't00-public-failure-witnesses-v1/native-request-examples-v3/sdk.json'
shutil.copyfile(sdk_path, HERE / 'sdk.frozen.json')
sdk = json.loads(sdk_path.read_text())
assert sdk['version'] == '5.9.3' and len(sdk['files']) == 100
sdk_roots = {Path(p).parent.as_posix() for p in sdk['files']}
assert len(sdk_roots) == 1
sdk_root = sdk_roots.pop()
for context, retained in [('legacy', False), ('retained', True)]:
    request = {'id': 'PUBLIC-AS-EXPRESSION-' + context.upper(), 'cwd': root.as_posix(),
               'sdk_directory': sdk_root, 'case_sensitive': False, 'roots': [source.as_posix()],
               'files': {source.as_posix(): text}, 'options': {'target': 'ES2022', 'module': 'ESNext',
               'moduleResolution': 'Bundler', 'allowJs': True, 'jsx': 'Preserve',
               'skipLibCheck': True, 'noEmit': True, 'strict': False},
               'retained': retained, 'qualified': False, 'roles': {}, 'selection': {},
               'disabled': [], 'utf16_files': {}, 'raw_files': {}}
    (HERE / ('request.' + context + '.local.json')).write_text(json.dumps(request, indent=2) + '\n', encoding='utf-8')
relative = 'packages/ts-analyzer/test/semantic-js-contracts.test.ts'
baseline = subprocess.check_output(['git', '-C', str(REPO), 'show', BASE + ':' + relative])
(HERE / 'historical-semantic-js-contracts.test.ts').write_bytes(baseline)
assert text.strip() in baseline.decode() or '((helper as () => number))()' in baseline.decode()
(HERE / 'historical-authority.json').write_text(json.dumps({'baseline': BASE, 'path': relative,
    'sha256': hashlib.sha256(baseline).hexdigest(), 'lines': [96, 103],
    'property_coordinate': [221, 1], 'source_sha256': hashlib.sha256(text.encode()).hexdigest(),
    'qualification_credit': 0}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'source_sha256': hashlib.sha256(text.encode()).hexdigest(), 'contexts': 2,
                  'candidate_queries': 0, 'host_actions': 0}))
