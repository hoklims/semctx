"""Synthetic reader sensitivity only; never native outcome evidence."""
import copy
import json
from pathlib import Path

import read_public as reader
from identity_scope_reader import digest, digest_bytes, logical_input

HERE = Path(__file__).resolve().parent
positive = 0
negative = []


def change(path, value):
    def apply(candidate):
        parent = candidate
        for item in path[:-1]:
            parent = parent[item]
        parent[path[-1]] = value
    return apply


for context in ('legacy', 'retained'):
    request = copy.deepcopy(reader.LOCAL[context])
    sdk = copy.deepcopy(reader.SDK)
    source = request['roots'][0]
    syntax = reader.EXPECTED['syntax_call']['call']
    observed = {'complete': True, 'global_admission_inferred': False, 'request': request['id'],
                'request_id': digest(request), 'input_manifest_id': digest(logical_input(request, sdk)),
                'producer_artifact_id': 'sha256:' + reader.ARTIFACT['macos'], 'sdk_version': '5.9.3',
                'ambient_native_case_sensitive': False, 'status': 'development_observation_not_qualification',
                'capture_probes': [{'operation': 'read_file', 'path': source, 'found': True,
                                    'content_id': digest_bytes(request['files'][source].encode())}],
                'subjects': [{'path': 'entry.ts', 'outcome': 'analyzed'}],
                'calls': [{'file': source, 'start_utf16': syntax['startUtf16'], 'end_utf16': syntax['endUtf16']}],
                'raw_extraction': copy.deepcopy(reader.EXPECTED['extractions'][context])}
    assert reader.read('macos', context, request, sdk, observed, physical=False)['qualification_credit'] == 0
    positive += 1
    mutants = {
        'opposite_context_calls': change(['raw_extraction', 'calls'], copy.deepcopy(reader.EXPECTED['extractions']['retained' if context == 'legacy' else 'legacy']['calls'])),
        'missing_call_syntax': change(['calls'], []),
        'foreign_call_source': change(['calls', 0, 'file'], source + '.other'),
        'changed_call_start': change(['calls', 0, 'start_utf16'], syntax['startUtf16'] + 1),
        'boolean_call_start': change(['calls', 0, 'start_utf16'], True),
        'missing_symbol': change(['raw_extraction', 'symbols'], []),
        'changed_owner_name': change(['raw_extraction', 'symbols', 1, 'name'], 'other'),
        'changed_symbol_scope': change(['raw_extraction', 'symbols', 1, 'scope'], ['foreign']),
        'foreign_artifact': change(['producer_artifact_id'], 'sha256:' + '0' * 64),
        'foreign_request': change(['request_id'], 'sha256:' + '0' * 64),
        'foreign_input': change(['input_manifest_id'], 'sha256:' + '0' * 64),
        'sdk_version_changed': change(['sdk_version'], '7.1.0-dev'),
        'source_read_digest_changed': change(['capture_probes', 0, 'content_id'], 'sha256:' + '0' * 64),
        'global_admission_forged': change(['global_admission_inferred'], True),
        'incomplete_observation': change(['complete'], False),
        'unsupported_subject': change(['subjects', 0, 'outcome'], 'unsupported'),
    }
    if context == 'retained':
        mutants.update({'foreign_callee': change(['raw_extraction', 'calls', 0, 'calleeSymbolPath'], 'other'),
                        'foreign_caller': change(['raw_extraction', 'calls', 0, 'callerSymbolPath'], 'other')})
    for name, mutate in mutants.items():
        value = copy.deepcopy(observed)
        mutate(value)
        try:
            reader.read('macos', context, request, sdk, value, physical=False)
        except (ValueError, KeyError, TypeError, IndexError) as error:
            negative.append({'context': context, 'name': name, 'rejected': True, 'diagnostic': str(error)})
        else:
            raise AssertionError('falsification accepted: ' + context + '/' + name)
    wrong_request = copy.deepcopy(request)
    wrong_request['retained'] = not request['retained']
    try:
        reader.read('macos', context, wrong_request, sdk, observed, physical=False)
    except ValueError as error:
        negative.append({'context': context, 'name': 'snapshot_context_swapped', 'rejected': True, 'diagnostic': str(error)})
    else:
        raise AssertionError('context substitution accepted')

output = {'kind': 'SYNTHETIC_PUBLIC_READER_CONTROLS_NOT_NATIVE_EVIDENCE', 'positive_controls': positive,
          'negative_controls': len(negative), 'results': negative, 'candidate_queries': 0,
          'qualification_credit': 0, 'R0_decision': None}
with (HERE / 'reader-controls.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(output, stream, indent=2)
    stream.write('\n')
print(json.dumps({'positive_controls': positive, 'negative_controls': len(negative), 'candidate_queries': 0}))
