"""Metadata-only native preparation: materialize public inputs, never commit or invoke C1."""
import argparse,hashlib,json,subprocess,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
PACKAGE=HERE.parent
HEAD='96fedbbe14e8585ae1c89e2656604bf5ecabf2c3'
ROOTS={'macos':'/Users/hokli/semctx-t00-build-evidence-20261021/public-native-regression-96fedbbe',
       'linux':'/work/evidence/public-native-regression-96fedbbe'}
PUBLIC6=['PUBLIC-01-value-namespace','PUBLIC-02-sdk-origin','PUBLIC-03-sdk-opaque-argument','PUBLIC-04-sdk-timer-category','PUBLIC-05-broad-declaration-scope','PUBLIC-06-reached-body-scope']
ENV4=['ENV-03-declaration-root','ENV-01-single-root','ENV-02-two-roots','CALL-01-immutable-alias']
CALL02='CALL-02-parenthesized-alias'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
def load(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def save(path,value):
    with Path(path).open('x',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def run(argv,cwd=None,timeout=120):
    started=time.monotonic();p=subprocess.run([str(v) for v in argv],cwd=cwd,capture_output=True,timeout=timeout)
    return {'argv':[str(v) for v in argv],'exitCode':p.returncode,'stdout':p.stdout.decode('utf-8',errors='replace'),
            'stderr':p.stderr.decode('utf-8',errors='replace'),'elapsedSeconds':time.monotonic()-started}
def git_read(repo,*argv):
    value=run(['git','-C',repo,*argv],timeout=30)
    need(value['exitCode']==0,'native prepared source Git read failed: '+value['stderr'])
    return value['stdout'].strip()
def package_check():
    freeze=load(PACKAGE/'PREPARATION-FREEZE.json')
    need(freeze['preparerSha256']==H(__file__) and freeze['sourceHead']==HEAD and freeze['executionAuthorized'] is False,'public preparation capsule differs')
    for pin in freeze['files']:
        path=PACKAGE/pin['path']
        need(H(path)==pin['sha256'] and path.stat().st_size==pin['bytes'],'frozen public preparation input differs: '+pin['path'])
    binding=load(HERE/'native-bindings.actual.disabled.json')
    need(binding['source_head']==HEAD and binding['execution_authorized'] is False,'actual native binding enabled/foreign')
    return binding
def actual_case_mode(root):
    probe=root/'PublicCaseModeProbe'
    need(not probe.exists(),'native case probe occupied')
    probe.write_bytes(b'public-96-case')
    try:return not (root/'publiccasemodeprobe').exists()
    finally:probe.unlink()
def source_check(binding):
    path=Path(binding['source_snapshot_path'])
    need(H(path)==binding['source_snapshot_sha256'],'96 source snapshot differs')
    snapshot=load(path)
    need(snapshot['head']==HEAD and snapshot['status']=='' and len(snapshot['files'])==227,'96 source snapshot HEAD/dirty differs')
    repo=Path(binding['source_repo_path'])
    need(git_read(repo,'rev-parse','HEAD')==HEAD and not git_read(repo,'status','--porcelain'),'96 native source checkout changed')
    for rel,pin in snapshot['files'].items():need(H(repo/rel)==pin,'96 native source byte drift: '+rel)
    return {'head':HEAD,'sourceSnapshotSha256':H(path),'sourceFiles':len(snapshot['files'])}
def prepared_environment(root,lane,binding):
    source=source_check(binding)
    pins={name:{'path':binding[field],'sha256':H(binding[field])} for name,field in [
        ('candidate','artifact_path'),('helper','helper_path'),('transport','transport_fixture_path'),
        ('observer','qualification_observer_path'),('caller','generic_caller_path')]}
    for name,field in [('candidate','artifact_sha256'),('helper','helper_sha256'),('transport','transport_fixture_sha256'),
                       ('observer','qualification_observer_sha256'),('caller','generic_caller_sha256')]:
        need(pins[name]['sha256']==binding[field],name+' prepared binary differs')
    need(H(binding['build_environment_path'])==binding['build_environment_sha256'],'96 build environment differs')
    need(H(binding['sdk_container_path'])==binding['sdk_container_sha256'],'96 prepared SDK container differs')
    need(H(binding['fixture_path'])==binding['fixture_sha256'],'96 prepared fixture differs')
    case=actual_case_mode(root)
    need(case is binding['native_case_sensitive'] and case is (lane=='linux'),'physical host case mode differs')
    return {'source':source,'pins':pins,'buildEnvironmentSha256':H(binding['build_environment_path']),
            'sdkContainerSha256':H(binding['sdk_container_path']),'fixtureSha256':H(binding['fixture_path']),
            'actualNativeCaseSensitive':case}
def public_sdk(path):
    sdk=load(path);frozen=load(PACKAGE/'frozen-v3/public-sdk-input.json')
    def values(x):
        result={Path(p).name:t for p,t in x['files'].items()}
        need(len(result)==len(x['files']),'SDK duplicate basename')
        return result
    need(sdk['version']==frozen['version']=='5.9.3' and sdk['archive_sha256']==frozen['archive_sha256'] and values(sdk)==values(frozen),'public SDK values differ')
    for p,text in sdk['files'].items():need(Path(p).read_bytes()==text.encode('utf-8'),'physical public SDK differs')
    return {'path':str(path),'sha256':H(path),'files':len(sdk['files']),'archiveSha256':sdk['archive_sha256']}
def planned_git(repo,source_files):
    need(not (repo/'.git').exists(),'Git fixture unexpectedly initialized before literal root commands')
    actual=sorted(p.relative_to(repo).as_posix() for p in repo.rglob('*') if p.is_file())
    need(actual==sorted(source_files),'public fixture initial file inventory differs')
    return {'repository':repo.as_posix(),'initialTrackedFiles':sorted(source_files),
            'initialSourcePins':{name:H(repo/name) for name in source_files},
            'literalArgv':[
              ['git','-C',repo.as_posix(),'init','-q','-b','public-witness'],
              ['git','-C',repo.as_posix(),'add','--','.'],
              ['git','-C',repo.as_posix(),'-c','user.name=PublicWitness','-c','user.email=public-witness@example.test','commit','-qm','fixture: public 96 regression']],
            'executedByPreparer':False}
def captured_names(request_path,repo):
    request=load(request_path)
    paths=list(request['files'])+list(request['raw_files'])
    return sorted(Path(p).relative_to(repo).as_posix() for p in paths)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True)
    ap.add_argument('--lane',choices=['macos','linux'],required=True)
    a=ap.parse_args();root=a.root.resolve()
    need(str(root)==ROOTS[a.lane] and root.is_dir(),'foreign public96 native root')
    binding=package_check()['lanes'][a.lane]
    env=prepared_environment(root,a.lane,binding)
    public6=root/'public6';public6.mkdir()
    p6=run([binding['python_path'],PACKAGE/'materialize_public_v4.py','--capsule',PACKAGE/'frozen-v3',
            '--output',public6/'inputs','--case-sensitive',str(env['actualNativeCaseSensitive']).lower()],cwd=root,timeout=120)
    save(root/'public6-transport-process.json',p6);need(p6['exitCode']==0,'PUBLIC6 materialization failed')
    sdk=public_sdk(public6/'inputs/sdk.json')
    env4=root/'env4';env4.mkdir()
    t=PACKAGE/'public-index-call-envelope-witness'/('v2/native_transport.py' if a.lane=='linux' else 'v4/native_transport.py')
    ev=run([binding['python_path'],t,'--output-root',env4/'inputs','--sdk-json',sdk['path']],cwd=root,timeout=120)
    save(root/'env4-transport-process.json',ev);need(ev['exitCode']==0,'ENV4 materialization failed')
    call02=root/'call02';call02.mkdir()
    ca=run([binding['python_path'],PACKAGE/'public-index-call-envelope-witness/v5/native_transport.py',
            '--lane',a.lane,'--output-root',call02/'inputs','--sdk-json',sdk['path']],cwd=root,timeout=120)
    save(root/'call02-transport-process.json',ca);need(ca['exitCode']==0,'CALL02 materialization failed')
    refusal=root/'refusal';refusal.mkdir()
    rf=run([binding['python_path'],PACKAGE/'public-index-refusal-witness/materialize_public.py',
            '--output-root',refusal/'inputs','--lane',a.lane],cwd=root,timeout=60)
    save(root/'refusal-transport-process.json',rf);need(rf['exitCode']==0,'included-nearest materialization failed')
    gitplans={}
    for case in PUBLIC6[4:]:
        repo=public6/'inputs'/case/'workspace'
        gitplans['public6/'+case]=planned_git(repo,captured_names(public6/'inputs'/case/'control/request.v4.text.json',repo))
    for case in ENV4:
        repo=env4/'inputs/cases'/case/'repo'
        gitplans['env4/'+case]=planned_git(repo,captured_names(env4/'inputs/cases'/case/'control/request.json',repo))
    repo=call02/'inputs/CALL-02-parenthesized-alias/repo'
    gitplans['call02/CALL-02-parenthesized-alias']=planned_git(repo,['entry.ts'])
    repo=refusal/'inputs/workspace'
    gitplans['refusal/included-nearest-config']=planned_git(repo,['.gitignore','base.json','src/selected.ts','src/tsconfig.json','tsconfig.json'])
    need(len(gitplans)==8,'public Git fixture plan count differs')
    requests={}
    for case in PUBLIC6:
        control=public6/'inputs'/case/'control'
        path=control/('request.json' if case in PUBLIC6[:4] else 'request.v4.text.json')
        requests['public6/'+case]={'path':str(path),'sha256':H(path)}
    for case in ENV4:
        path=env4/'inputs/cases'/case/'control/request.json'
        requests['env4/'+case]={'path':str(path),'sha256':H(path)}
    path=call02/'inputs/CALL-02-parenthesized-alias/control/request.json'
    requests['call02/CALL-02-parenthesized-alias']={'path':str(path),'sha256':H(path)}
    path=refusal/'inputs/control/index-request.json'
    requests['refusal/included-nearest-config']={'path':str(path),'sha256':H(path),
       'physicalInitialSourceSha256':H(refusal/'inputs/workspace/src/selected.ts'),
       'capturedDirtySourceSha256':H(PACKAGE/'public-index-refusal-witness/fixture/source-current/src/selected.ts')}
    need(len(requests)==12,'public request count differs')
    result={'schema':1,'state':'PUBLIC_96_NATIVE_METADATA_ONLY_PREPARED_GIT_PENDING_NO_C1',
            'lane':a.lane,'sourceHead':HEAD,'actualPreparedSummarySha256':load(HERE/'native-bindings.actual.disabled.json')['prepared_summary_sha256'],
            'candidateQueries':0,'candidateBuilds':0,'gitCommits':0,'executionAuthorized':False,
            'preflight':env,'publicSdk':sdk,
            'transportSha256':{'public6':H(root/'public6-transport-process.json'),'env4':H(root/'env4-transport-process.json'),
                               'call02':H(root/'call02-transport-process.json'),'refusal':H(root/'refusal-transport-process.json')},
            'gitPlans':gitplans,'requests':requests,'plannedCandidatePhases':19,'qualificationCredit':0}
    save(root/'METADATA-PREPARE-RECEIPT.json',result)
    print(json.dumps({'lane':a.lane,'prepareReceiptSha256':H(root/'METADATA-PREPARE-RECEIPT.json'),
                      'requests':len(requests),'gitPlans':len(gitplans),'gitCommits':0,'candidateQueries':0}))
if __name__=='__main__':main()
