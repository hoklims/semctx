"""Stage the one frozen public source and both contexts; no candidate process."""
import argparse
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--lane', choices=['macos', 'linux'], required=True)
args = parser.parse_args()
manifest = json.loads((HERE / 'manifest.frozen.json').read_bytes())
for row in manifest['files']:
    raw = (HERE / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
root = args.root
assert root.is_absolute() and not root.exists()
root.mkdir(mode=0o700)
(root / 'CaseProbe').write_bytes(b'case')
sensitive = not (root / 'caseprobe').exists()
(root / 'CaseProbe').unlink()
assert sensitive is (args.lane == 'linux')
repo = root / 'repo'
repo.mkdir()
source = (HERE / 'fixture/repo/entry.ts').read_bytes()
(repo / 'entry.ts').write_bytes(source)
sdk = json.loads((HERE / 'sdk.frozen.json').read_bytes())
sdk_dir = root / 'sdk/lib'
sdk_dir.mkdir(parents=True)
mapped = {}
for path, text in sdk['files'].items():
    name = path.replace('\\', '/').rsplit('/', 1)[-1]
    assert re.fullmatch(r'[A-Za-z0-9_.-]+', name)
    target = sdk_dir / name
    assert not target.exists()
    target.write_bytes(text.encode())
    mapped[target.as_posix()] = text
sdk['files'] = mapped
(root / 'sdk.json').write_text(json.dumps(sdk, indent=2) + '\n', encoding='utf-8')
for context in ('legacy', 'retained'):
    request = json.loads((HERE / ('request.' + context + '.local.json')).read_bytes())
    request.update(cwd=repo.as_posix(), sdk_directory=sdk_dir.as_posix(), case_sensitive=sensitive,
                   roots=[(repo / 'entry.ts').as_posix()], files={(repo / 'entry.ts').as_posix(): source.decode()})
    (root / ('request.' + context + '.json')).write_text(json.dumps(request, indent=2) + '\n', encoding='utf-8')
files = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}
receipt = {'state': 'PUBLIC_AS_EXPRESSION_INPUTS_ONLY_NO_CANDIDATE', 'lane': args.lane, 'root': str(root),
           'native_case_sensitive': sensitive, 'manifest_sha256': hashlib.sha256((HERE / 'manifest.frozen.json').read_bytes()).hexdigest(),
           'files': files, 'candidate_queries': 0, 'candidate_builds': 0, 'execution_authorized': False}
(root / 'input-freeze.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt))
