export function helper() { return 1; }
export function caller() { return ((helper as () => number))(); }
