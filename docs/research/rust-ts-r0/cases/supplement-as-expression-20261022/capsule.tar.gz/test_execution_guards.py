"""Exercise exact authority/root/replay guards locally, without subprocesses."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile

import execute_native_v2 as execution

HERE = Path(__file__).resolve().parent
results = []


def reject(name, action):
    try:
        action()
    except (ValueError, RuntimeError, FileExistsError, FileNotFoundError) as error:
        results.append({'case': name, 'rejected': True, 'diagnostic': str(error)})
    else:
        raise AssertionError('unsafe control accepted: ' + name)


expected = {'schema': 1, 'explicit_root_go': True, 'lane': 'macos', 'source_head': '96fedbbe14e8585ae1c89e2656604bf5ecabf2c3',
            'metadata_preflight_sha256': 'a' * 64, 'input_freeze_sha256': 'b' * 64,
            'staging_freeze_sha256': 'c' * 64, 'execution_runner_sha256': 'd' * 64, 'candidate_sha256': 'e' * 64,
            'max_candidate_queries': 2, 'attempt_limit': 1, 'timeout_ms': 20000, 'output_cap_bytes_per_stream': 8388608,
            'candidate_builds': 0, 'qualification_credit': 0, 'R0_decision': None,
            'input_root': '/example/root', 'execution_freeze_sha256': 'f' * 64}
assert len(expected) == 18
execution.validate_go(copy.deepcopy(expected), expected)
for name, field, value in [
    ('boolean_schema', 'schema', True), ('integer_root_authority', 'explicit_root_go', 1),
    ('boolean_attempt_limit', 'attempt_limit', True), ('boolean_zero_credit', 'qualification_credit', False),
    ('foreign_candidate_pin', 'candidate_sha256', '0' * 64), ('wrong_phase_count', 'max_candidate_queries', 1),
    ('wrong_root', 'input_root', '/copied/root'), ('wrong_freeze', 'execution_freeze_sha256', '0' * 64),
    ('wrong_lane', 'lane', 'linux'), ('second_attempt', 'attempt_limit', 2),
]:
    value_go = copy.deepcopy(expected)
    value_go[field] = value
    reject(name, lambda go=value_go: execution.validate_go(go, expected))
extra = dict(expected, self_authorized=True)
reject('unknown_authority_key', lambda: execution.validate_go(extra, expected))
with tempfile.TemporaryDirectory(prefix='as-expression-guards-', dir=HERE) as temporary:
    base = Path(temporary).resolve()
    root = base / 'root'
    root.mkdir()
    other = base / 'copy'
    other.mkdir()
    go_path = root / 'ROOT-GO-macos.json'
    go_path.write_bytes(b'authority')
    copy_go = other / go_path.name
    copy_go.write_bytes(go_path.read_bytes())
    assert execution.validate_root(root.as_posix(), root) == root
    assert execution.validate_root(go_path.as_posix(), go_path) == go_path
    reject('copied_input_root', lambda: execution.validate_root(other.as_posix(), root))
    reject('relative_root', lambda: execution.validate_root('root', root))
    reject('dot_root_alias', lambda: execution.validate_root(root.as_posix() + '/.', root))
    reject('parent_root_alias', lambda: execution.validate_root(other.as_posix() + '/../root', root))
    reject('copied_identical_GO', lambda: execution.validate_root(copy_go.as_posix(), go_path))
    reject('dot_GO_alias', lambda: execution.validate_root(root.as_posix() + '/./ROOT-GO-macos.json', go_path))
    execution.claim_once(root, 'a' * 64)
    before = (root / 'ONE-SHOT-QUERY-CLAIM.json').read_bytes()
    reject('one_shot_claim_replay', lambda: execution.claim_once(root, 'a' * 64))
    assert (root / 'ONE-SHOT-QUERY-CLAIM.json').read_bytes() == before
    claim_digest = hashlib.sha256(before).hexdigest()
output = {'kind': 'LOCAL_TWO_CONTEXT_EXECUTION_GUARDS_NOT_NATIVE', 'positive_controls': 4,
          'negative_controls': len(results), 'typed_query_go_keys': 18, 'phase_count': 2,
          'claim_unchanged_sha256': claim_digest, 'results': results,
          'candidate_queries': 0, 'host_actions': 0, 'qualification_credit': 0, 'R0_decision': None}
with (HERE / 'execution-guard-controls.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(output, stream, indent=2)
    stream.write('\n')
print(json.dumps({'positive_controls': 4, 'negative_controls': len(results), 'candidate_queries': 0, 'host_actions': 0}))
