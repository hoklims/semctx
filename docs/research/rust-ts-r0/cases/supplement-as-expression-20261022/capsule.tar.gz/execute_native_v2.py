"""Two fixed native contexts, each once; separate root GO and finally postflight."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

import native_preflight as preflight
import read_public

HERE = Path(__file__).resolve().parent
CONTEXTS = ('legacy', 'retained')


def validate_root(raw, expected):
    root = Path(raw)
    preflight.prepared.need(isinstance(raw, str) and raw == expected.as_posix() and root.is_absolute(), 'exact frozen root differs')
    preflight.prepared.need(not root.is_symlink() and root.resolve(strict=True) == root, 'root alias differs')
    return root


def validate_go(go, expected):
    preflight.prepared.need(type(go) is dict and set(go) == set(expected), 'root GO exact key set differs')
    for key, value in expected.items():
        preflight.prepared.need(type(go[key]) is type(value) and go[key] == value, 'typed root GO differs: ' + key)


def claim_once(root, go_sha):
    preflight.save(root / 'ONE-SHOT-QUERY-CLAIM.json', {'root_go_sha256': go_sha, 'phase_count': 2,
                   'contexts': list(CONTEXTS), 'attempt_limit_per_context': 1, 'retries': 0})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lane', choices=['macos', 'linux'], required=True)
    parser.add_argument('--root', required=True)
    parser.add_argument('--go', required=True)
    parser.add_argument('--go-sha256', required=True)
    args = parser.parse_args()
    plan = preflight.load(HERE / 'native-plan.disabled.json')['platforms'][args.lane]
    validate_root(HERE.as_posix(), Path(plan['proposed_tools_root']))
    root = validate_root(args.root, Path(plan['proposed_input_root']))
    go_path = validate_root(args.go, HERE / ('ROOT-GO-' + args.lane + '.json'))
    successor = preflight.load(HERE / 'EXECUTION-FREEZE-V2.json')
    preflight.prepared.need(successor['execution_runner_sha256'] == preflight.sha(__file__) and
                            successor['phase_count'] == 2 and successor['contexts'] == list(CONTEXTS), 'execution successor differs')
    before, binding = preflight.stable_inputs(args.lane, root)
    receipt = root / 'METADATA-PREFLIGHT-RECEIPT.json'
    prepared = preflight.load(receipt)
    preflight.prepared.need(before == prepared['preflight'], 'actual frozen preflight changed')
    raw = go_path.read_bytes()
    preflight.prepared.need(hashlib.sha256(raw).hexdigest() == args.go_sha256, 'root GO byte pin differs')
    go = json.loads(raw)
    expected = {'schema': 1, 'explicit_root_go': True, 'lane': args.lane, 'source_head': preflight.prepared.HEAD,
                'metadata_preflight_sha256': preflight.sha(receipt), 'input_freeze_sha256': before['inputFreezeSha256'],
                'staging_freeze_sha256': preflight.sha(HERE / 'STAGING-FREEZE.json'),
                'execution_runner_sha256': preflight.sha(__file__), 'candidate_sha256': binding['artifact_sha256'],
                'max_candidate_queries': 2, 'attempt_limit': 1, 'timeout_ms': 20000,
                'output_cap_bytes_per_stream': 8388608, 'candidate_builds': 0, 'qualification_credit': 0,
                'R0_decision': None, 'input_root': str(root),
                'execution_freeze_sha256': preflight.sha(HERE / 'EXECUTION-FREEZE-V2.json')}
    validate_go(go, expected)
    evidence = root / 'evidence'
    evidence_owned = False
    actual_queries = 0
    phase_records = []
    state = 'FAILED'
    failure = None
    try:
        claim_once(root, args.go_sha256)
        evidence.mkdir()
        evidence_owned = True
        sdk = preflight.load(root / 'sdk.json')
        input_pins = preflight.load(root / 'input-freeze.json')['files']
        pins = list(before['environment']['pins'].values())
        pins.extend({'path': str(root / rel), 'sha256': digest} for rel, digest in input_pins.items())
        pins.extend({'path': binding[field], 'sha256': binding[pin]} for field, pin in [
            ('build_environment_path', 'build_environment_sha256'), ('fixture_path', 'fixture_sha256'),
            ('sdk_container_path', 'sdk_container_sha256'), ('source_snapshot_path', 'source_snapshot_sha256')])
        env = os.environ.copy()
        env.update(GOPORT_LIB_PARSE_SNAPSHOT='0', GOPORT_LIB_SNAPSHOT='0', GIT_CONFIG_GLOBAL='/dev/null',
                   GIT_CONFIG_NOSYSTEM='1', GIT_TERMINAL_PROMPT='0', PYTHONDONTWRITEBYTECODE='1')
        for context in CONTEXTS:
            current, _ = preflight.stable_inputs(args.lane, root)
            preflight.prepared.need(current == before, 'input changed between contexts')
            request_path = root / ('request.' + context + '.json')
            request = preflight.load(request_path)
            spec = {'schema': 1, 'execution_authorized': True,
                    'argv': [binding['artifact_path'], str(request_path), str(root / 'sdk.json')],
                    'cwd': str(root / 'repo'), 'helper': binding['helper_path'], 'timeout_ms': 20000,
                    'output_cap': 8388608, 'pins': pins, 'candidate_query': True}
            spec_path = evidence / (context + '.spec.json')
            preflight.save(spec_path, spec)
            argv = [binding['generic_caller_path'], str(spec_path), str(evidence / context)]
            phase = {'context': context, 'query_attempted': True, 'candidate_queries': None}
            phase_records.append(phase)
            process = subprocess.run(argv, cwd=root, env=env, capture_output=True, timeout=45)
            preflight.save(evidence / (context + '.caller.json'), {'argv': argv, 'exit_code': process.returncode,
                           'stdout': process.stdout.decode('utf-8', 'replace'), 'stderr': process.stderr.decode('utf-8', 'replace')})
            preflight.prepared.need(process.returncode == 0, 'bounded caller failed; no retry')
            outcome = preflight.load(evidence / context / 'process-outcome.json')
            phase['candidate_queries'] = 1
            actual_queries += 1
            for stream in ('stdout', 'stderr'):
                data = (evidence / context / (stream + '.raw')).read_bytes()
                preflight.prepared.need(len(data) == outcome[stream + '_bytes'] and
                                        hashlib.sha256(data).hexdigest() == outcome[stream + '_hash'] and
                                        len(data) <= 8388608, 'actual stream identity/cap differs')
            preflight.prepared.need(outcome['kind'] == 'success' and type(outcome['exit_code']) is int and
                                    outcome['exit_code'] == 0, 'candidate non-success; preserve and stop')
            result = read_public.read(args.lane, context, request, sdk,
                                      json.loads((evidence / context / 'stdout.raw').read_bytes()))
            preflight.save(evidence / (context + '.adjudication.json'), result)
            phase['adjudication_state'] = result['state']
        state = 'PUBLIC_AS_EXPRESSION_TWO_CONTEXTS_PASS'
    except Exception as error:
        failure = str(error)
        raise
    finally:
        postflight_error = None
        try:
            after, _ = preflight.stable_inputs(args.lane, root)
            preflight.prepared.need(after == before, 'native/input postflight changed')
            postflight_ok = True
        except Exception as error:
            postflight_ok = False
            postflight_error = str(error)
        result = {'schema': 1, 'state': state, 'lane': args.lane, 'source_head': preflight.prepared.HEAD,
                  'phase_count': 2, 'contexts': list(CONTEXTS), 'phases': phase_records,
                  'candidate_queries': actual_queries if all(p['candidate_queries'] is not None for p in phase_records) else None,
                  'query_attempts': len(phase_records), 'attempt_limit_per_context': 1, 'retries': 0, 'candidate_builds': 0,
                  'postflight_ok': postflight_ok, 'postflight_error': postflight_error, 'failure': failure,
                  'root_go_sha256': args.go_sha256, 'metadata_preflight_sha256': preflight.sha(receipt),
                  'qualification_credit': 0, 'R0_decision': None}
        if evidence_owned:
            preflight.save(evidence / 'RESULT.json', result)
        if not postflight_ok:
            raise RuntimeError('public native postflight failed: ' + str(postflight_error))
    print(json.dumps(result))


if __name__ == '__main__':
    main()
