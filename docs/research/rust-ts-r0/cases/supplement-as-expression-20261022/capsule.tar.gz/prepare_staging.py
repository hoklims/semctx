"""Prepare metadata/transport source locally; no host or candidate invocation."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / 'public-scoped-call-witness'
H = lambda raw: hashlib.sha256(raw).hexdigest()
BASE = 'c63f6c126b5a91155fb379034a1c756f3f2f0de487e5bfc628529a5a506f550b'
assert H((HERE / 'manifest.frozen.json').read_bytes()) == BASE
original = json.loads((HERE / 'manifest.frozen.json').read_bytes())
for row in original['files']:
    raw = (HERE / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and H(raw) == row['sha256']
derivations = []


def derive(source, target, replacements):
    before = source.read_bytes()
    after = before
    changes = []
    for old, new in replacements:
        count = after.count(old.encode())
        assert count > 0, old
        after = after.replace(old.encode(), new.encode())
        changes.append({'before': old, 'after': new, 'occurrences': count})
    if target.suffix == '.py':
        ast.parse(after.decode(), filename=str(target))
    with target.open('xb') as stream:
        stream.write(after)
    derivations.append({'source': str(source), 'source_sha256': H(before), 'target': str(target),
                        'target_sha256': H(after), 'replacements': changes,
                        'diff': ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True)))})


derive(OLD / 'public96_preflight.py', HERE / 'public96_preflight.py', [])
derive(OLD / 'native-bindings.actual.disabled.json', HERE / 'native-bindings.actual.disabled.json', [])
derive(OLD / 'native_preflight.py', HERE / 'native_preflight.py', [
    ('8acf4b937dd802db423cd248aba24f7e9f40d7cfa215a2fcfc3dcf68fe5e1cb0', BASE),
    ("    request=load(root/'request.json');sdk=load(root/'sdk.json')\n    read_public.check_inputs(lane,request,sdk)",
     "    sdk=load(root/'sdk.json')\n    requests={}\n    for context in ('legacy','retained'):\n        path=root/('request.'+context+'.json')\n        request=load(path)\n        read_public.check_inputs(lane,context,request,sdk)\n        requests[context]=sha(path)"),
    ("'requestSha256':sha(root/'request.json')", "'requestSha256':requests"),
    ('PUBLIC_SCOPED_METHOD_NATIVE_PREFLIGHT_NO_C1', 'PUBLIC_AS_EXPRESSION_NATIVE_PREFLIGHT_NO_C1'),
    ("sha(HERE/'execute_native.py')", "sha(HERE/'execute_native_v2.py')"),
    ("'staging_freeze_sha256':sha(HERE/'STAGING-FREEZE.json'),", "'staging_freeze_sha256':sha(HERE/'STAGING-FREEZE.json'),\n            'execution_freeze_sha256':sha(HERE/'EXECUTION-FREEZE-V2.json'),"),
])
staging = HERE / 'staging-v1'
staging.mkdir()
with (staging / 'DERIVATION.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(derivations, stream, indent=2)
    stream.write('\n')
print(json.dumps({'derived_sources': len(derivations), 'candidate_queries': 0, 'host_actions': 0}))
