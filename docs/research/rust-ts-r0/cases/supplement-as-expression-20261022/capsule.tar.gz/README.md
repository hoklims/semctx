# One public as-expression extraction contrast

This separately frozen public witness addresses only the demonstrated missing
carrier for property `(221,1)`. It does not change the original 354 units,
395 properties, 51 supports, expectations or private sealed cases. No private
case, mapping or payload was read. No Semctx checkout was edited.

The source is the exact minimal program from frozen baseline
`3e94997fcbefa72ad4d49b2cad180ee79b7c0a9b`,
`packages/ts-analyzer/test/semantic-js-contracts.test.ts:96-103`:

```typescript
export function helper() { return 1; }
export function caller() { return ((helper as () => number))(); }
```

Two actual production `extractTypeScript` calls ran with TypeScript 5.9.3 and
Bun 1.4.3. The production source is Git blob
`2400cdd94c0903195df82c2b2c387bcbaa1513b0`, SHA256
`9e025956b492b77cd13c59e9b5196c76506367db484180f28824ccd508665d7f`.
The two calls use the same bounded `ts.sys`: exact source plus the supplied
100-library SDK, with automatic ambient type-directory enumeration disabled.
The production extractor and its `createProgram` implementation are unchanged;
the wrapper records the actual Program sources and reads. Only the supplied
snapshot argument differs: absent for legacy, actual source Map for retained.

Each Program consumed 64 source/library files with physical bytes matching the
frozen source/SDK and zero syntactic or semantic diagnostics. Both see the same
CallExpression at UTF16 `[73,101]`, whose expression is parenthesized. The
legacy extraction has no canonical calls. The retained extraction has exactly
`entry.ts/caller -> entry.ts/helper`, with `calleeName: helper` and line 2.
The complete actual projections and read records remain in
`baseline.actual.json`, SHA256
`3b78cf0daad9c0c8782f75c4ffd22247aaa82257e89bc88e742f5ee3ba82e899`.

Preparation histories are explicit. An initial source write used Windows CRLF
while the declared request had LF; that attempt stopped before Program creation.
After physical bytes were corrected to the already declared LF, an unbounded
ordinary Program found an ambient home `@types` package and was refused before
any oracle was emitted. Its source script and refusal record are preserved under
`history/`. The final successful run uses the explicit bounded system above for
both contexts. Actual process output is in tool history; separate process log
files were not created. No failed attempt is retagged as the successful reference.

`expected-oracle.json` is derived only from those actual TypeScript outputs.
`read_public.py` verifies the native request, options, context flag, source bytes,
SDK, logical input identity, artifact identity, captured source read, complete
subject and unique syntax Call range. It checks the complete canonical calls,
module/import inventory and all baseline symbol fields. Native-only symbol UTF16
fields are separately type/range checked. It grants no global admission, ownership,
qualification or global absence credit. Legacy empty calls mean only this source
and this specific legacy context.

Two positive synthetic controls and 36 falsifications passed. Controls reject
context swaps, opposite call inventories, wrong caller/callee, missing symbols,
wrong scopes, Boolean coordinates, request/input/artifact/SDK substitutions,
source read changes and invented global admission. These are reader sensitivity
checks, not native executions.

The native ABI already has the exact context distinction: `main.rs` computes
`static_module_links = retained || javascript_enabled`, and
`ordinary.rs::SymbolWalker::call` unwraps its callee only when those links are
enabled. Both proposed requests select the same physical TS source and SDK,
set `qualified: false`, and differ only in `id` and `retained`. The one source
has no JS roots. No producer correction is proposed from this source inspection.

`native-plan.disabled.json` proposes two bounded direct C1 invocations per host,
legacy then retained, on the parent's already built source-96 artifacts. A
separate concrete metadata preflight and root GO are required. Inputs, source,
all binaries, build metadata and SDK must remain pinned before and after; raw
exit/stdout/stderr/process evidence must remain unchanged. No retry or build is
included. `materialize_native.py` only creates a new owned input directory and
its two physical requests. This preparation performed no host action, candidate
query, build, Git mutation, qualification or R0 decision.
